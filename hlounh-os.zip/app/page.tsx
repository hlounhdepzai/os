"use client"

import { useState, useEffect } from "react"
import Desktop from "@/components/desktop"

export default function HLounhOS() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return <Desktop currentTime={currentTime} />
}

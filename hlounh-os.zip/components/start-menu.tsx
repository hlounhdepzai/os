"use client"

import { useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import {
  FileText,
  Calculator,
  Folder,
  Settings,
  Terminal,
  ImageIcon,
  Music,
  Power,
  User,
  Search,
  Globe,
  Code,
} from "lucide-react"

interface StartMenuProps {
  onOpenApp: (appName: string, title: string) => void
  onClose: () => void
}

const menuApps = [
  { name: "file-manager", title: "Quản lý tệp", icon: Folder },
  { name: "text-editor", title: "Soạn thảo văn bản", icon: FileText },
  { name: "calculator", title: "Máy tính", icon: Calculator },
  { name: "web-browser", title: "Trình duyệt", icon: Globe },
  { name: "python-coder", title: "Python Coder", icon: Code },
  { name: "settings", title: "Cài đặt", icon: Settings },
  { name: "terminal", title: "Terminal", icon: Terminal },
  { name: "image-viewer", title: "Xem ảnh", icon: ImageIcon },
  { name: "music-player", title: "Nghe nhạc", icon: Music },
]

export default function StartMenu({ onOpenApp, onClose }: StartMenuProps) {
  const menuRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose()
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    return () => document.removeEventListener("mousedown", handleClickOutside)
  }, [onClose])

  const handleAppClick = (appName: string, title: string) => {
    onOpenApp(appName, title)
    onClose()
  }

  return (
    <div
      ref={menuRef}
      className="absolute bottom-12 left-2 w-80 bg-black/90 backdrop-blur-md rounded-lg border border-white/20 overflow-hidden"
    >
      {/* User Section */}
      <div className="p-4 border-b border-white/20">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="text-white font-medium">Người dùng</div>
            <div className="text-white/60 text-sm">HLounh OS</div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="p-3 border-b border-white/20">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-white/60" />
          <input
            type="text"
            placeholder="Tìm kiếm..."
            className="w-full pl-10 pr-3 py-2 bg-white/10 border border-white/20 rounded text-white placeholder-white/60 focus:outline-none focus:border-blue-400"
          />
        </div>
      </div>

      {/* Apps */}
      <div className="p-2">
        <div className="text-white/60 text-xs font-medium mb-2 px-2">Ứng dụng</div>
        {menuApps.map((app) => {
          const IconComponent = app.icon
          return (
            <Button
              key={app.name}
              variant="ghost"
              className="w-full justify-start text-white hover:bg-white/20 mb-1"
              onClick={() => handleAppClick(app.name, app.title)}
            >
              <IconComponent className="w-5 h-5 mr-3" />
              {app.title}
            </Button>
          )
        })}
      </div>

      {/* Power Options */}
      <div className="p-2 border-t border-white/20">
        <Button
          variant="ghost"
          className="w-full justify-start text-white hover:bg-white/20"
          onClick={() => window.location.reload()}
        >
          <Power className="w-5 h-5 mr-3" />
          Khởi động lại
        </Button>
      </div>
    </div>
  )
}

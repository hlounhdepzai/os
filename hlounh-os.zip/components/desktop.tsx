"use client"

import { useState } from "react"
import Taskbar from "@/components/taskbar"
import WindowManager from "@/components/window-manager"
import DesktopIcons from "@/components/desktop-icons"
import PasswordPrompt from "@/components/password-prompt"

interface DesktopProps {
  currentTime: Date
}

export interface AppWindow {
  id: string
  title: string
  component: string
  isMinimized: boolean
  position: { x: number; y: number }
  size: { width: number; height: number }
  zIndex: number
}

export default function Desktop({ currentTime }: DesktopProps) {
  const [windows, setWindows] = useState<AppWindow[]>([])
  const [nextZIndex, setNextZIndex] = useState(1000)
  const [hasPassword, setHasPassword] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(true)
  const [showPasswordPrompt, setShowPasswordPrompt] = useState(false)
  const [pendingApp, setPendingApp] = useState<{ name: string; title: string } | null>(null)

  const openApp = (appName: string, title: string) => {
    // Kiểm tra nếu là Settings và đã có mật khẩu nhưng chưa xác thực
    if (appName === "settings" && hasPassword && !isAuthenticated) {
      setPendingApp({ name: appName, title })
      setShowPasswordPrompt(true)
      return
    }

    const existingWindow = windows.find((w) => w.component === appName)
    if (existingWindow) {
      // Bring to front if already open
      setWindows((prev) =>
        prev.map((w) => (w.id === existingWindow.id ? { ...w, isMinimized: false, zIndex: nextZIndex } : w)),
      )
      setNextZIndex((prev) => prev + 1)
      return
    }

    const newWindow: AppWindow = {
      id: `${appName}-${Date.now()}`,
      title,
      component: appName,
      isMinimized: false,
      position: { x: 100 + windows.length * 30, y: 100 + windows.length * 30 },
      size: { width: 800, height: 600 },
      zIndex: nextZIndex,
    }

    setWindows((prev) => [...prev, newWindow])
    setNextZIndex((prev) => prev + 1)
  }

  const closeWindow = (id: string) => {
    setWindows((prev) => prev.filter((w) => w.id !== id))
  }

  const minimizeWindow = (id: string) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, isMinimized: true } : w)))
  }

  const restoreWindow = (id: string) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, isMinimized: false, zIndex: nextZIndex } : w)))
    setNextZIndex((prev) => prev + 1)
  }

  const updateWindow = (id: string, updates: Partial<AppWindow>) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, ...updates } : w)))
  }

  const bringToFront = (id: string) => {
    setWindows((prev) => prev.map((w) => (w.id === id ? { ...w, zIndex: nextZIndex } : w)))
    setNextZIndex((prev) => prev + 1)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 relative overflow-hidden">
      {/* Desktop Background */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-30"
        style={{
          backgroundImage: `url('/placeholder.svg?height=1080&width=1920')`,
        }}
      />

      {/* Desktop Icons */}
      <DesktopIcons onOpenApp={openApp} />

      {/* Window Manager */}
      <WindowManager
        windows={windows}
        onClose={closeWindow}
        onMinimize={minimizeWindow}
        onUpdate={updateWindow}
        onBringToFront={bringToFront}
      />

      {/* Taskbar */}
      <Taskbar currentTime={currentTime} windows={windows} onOpenApp={openApp} onRestoreWindow={restoreWindow} />

      {/* Password Prompt */}
      {showPasswordPrompt && (
        <PasswordPrompt
          onClose={() => {
            setShowPasswordPrompt(false)
            setPendingApp(null)
          }}
          onSuccess={() => {
            setIsAuthenticated(true)
            if (pendingApp) {
              // Mở app đang chờ
              const newWindow: AppWindow = {
                id: `${pendingApp.name}-${Date.now()}`,
                title: pendingApp.title,
                component: pendingApp.name,
                isMinimized: false,
                position: { x: 100 + windows.length * 30, y: 100 + windows.length * 30 },
                size: { width: 800, height: 600 },
                zIndex: nextZIndex,
              }
              setWindows((prev) => [...prev, newWindow])
              setNextZIndex((prev) => prev + 1)
              setPendingApp(null)
            }
          }}
          title="Truy cập Cài đặt"
        />
      )}
    </div>
  )
}

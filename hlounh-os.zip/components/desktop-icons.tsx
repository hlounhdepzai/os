"use client"

import { FileText, Calculator, Folder, Settings, Terminal, ImageIcon, Music, Globe, Code } from "lucide-react"

interface DesktopIconsProps {
  onOpenApp: (appName: string, title: string) => void
}

const desktopApps = [
  { name: "file-manager", title: "Quản lý tệp", icon: Folder },
  { name: "text-editor", title: "Soạn thảo văn bản", icon: FileText },
  { name: "calculator", title: "Máy tính", icon: Calculator },
  { name: "web-browser", title: "Trình duyệt", icon: Globe },
  { name: "python-coder", title: "Python Coder", icon: Code },
  { name: "settings", title: "Cài đặt", icon: Settings },
  { name: "terminal", title: "Terminal", icon: Terminal },
  { name: "image-viewer", title: "Xem ảnh", icon: ImageIcon },
  { name: "music-player", title: "Nghe nhạc", icon: Music },
]

export default function DesktopIcons({ onOpenApp }: DesktopIconsProps) {
  return (
    <div className="absolute top-4 left-4 grid grid-cols-1 gap-4">
      {desktopApps.map((app, index) => {
        const IconComponent = app.icon
        return (
          <div
            key={app.name}
            className="flex flex-col items-center cursor-pointer group"
            onDoubleClick={() => onOpenApp(app.name, app.title)}
          >
            <div className="p-3 bg-white/20 backdrop-blur-sm rounded-lg group-hover:bg-white/30 transition-all">
              <IconComponent className="w-8 h-8 text-white" />
            </div>
            <span className="text-white text-xs mt-1 text-center max-w-16 truncate">{app.title}</span>
          </div>
        )
      })}
    </div>
  )
}

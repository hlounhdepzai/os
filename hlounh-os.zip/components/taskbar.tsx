"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, Wifi, Volume2, Battery } from "lucide-react"
import StartMenu from "@/components/start-menu"
import type { AppWindow } from "@/components/desktop"

interface TaskbarProps {
  currentTime: Date
  windows: AppWindow[]
  onOpenApp: (appName: string, title: string) => void
  onRestoreWindow: (id: string) => void
}

export default function Taskbar({ currentTime, windows, onOpenApp, onRestoreWindow }: TaskbarProps) {
  const [showStartMenu, setShowStartMenu] = useState(false)

  return (
    <>
      {/* Start Menu */}
      {showStartMenu && <StartMenu onOpenApp={onOpenApp} onClose={() => setShowStartMenu(false)} />}

      {/* Taskbar */}
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-black/80 backdrop-blur-md border-t border-white/20 flex items-center px-2">
        {/* Start Button */}
        <Button
          variant="ghost"
          size="sm"
          className="text-white hover:bg-white/20"
          onClick={() => setShowStartMenu(!showStartMenu)}
        >
          <Menu className="w-5 h-5 mr-2" />
          HLounh
        </Button>

        {/* Window Buttons */}
        <div className="flex-1 flex items-center space-x-1 mx-4">
          {windows.map((window) => (
            <Button
              key={window.id}
              variant="ghost"
              size="sm"
              className={`text-white hover:bg-white/20 max-w-48 truncate ${window.isMinimized ? "opacity-60" : ""}`}
              onClick={() => onRestoreWindow(window.id)}
            >
              {window.title}
            </Button>
          ))}
        </div>

        {/* System Tray */}
        <div className="flex items-center space-x-2 text-white">
          <Wifi className="w-4 h-4" />
          <Volume2 className="w-4 h-4" />
          <Battery className="w-4 h-4" />
          <div className="text-sm font-mono">
            {currentTime.toLocaleTimeString("vi-VN", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
        </div>
      </div>
    </>
  )
}

"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Monitor, Volume2, Wifi, Shield, Palette, User, HardDrive, Info } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function Settings() {
  const [activeTab, setActiveTab] = useState("display")
  const [currentPassword, setCurrentPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [hasPassword, setHasPassword] = useState(false)

  useEffect(() => {
    const savedPassword = localStorage.getItem("hlounh_password")
    setHasPassword(!!savedPassword)
  }, [])

  const settingsTabs = [
    { id: "display", name: "Hiển thị", icon: Monitor },
    { id: "sound", name: "Âm thanh", icon: Volume2 },
    { id: "network", name: "Mạng", icon: Wifi },
    { id: "security", name: "Bảo mật", icon: Shield },
    { id: "personalization", name: "Cá nhân hóa", icon: Palette },
    { id: "accounts", name: "Tài khoản", icon: User },
    { id: "storage", name: "Lưu trữ", icon: HardDrive },
    { id: "about", name: "Thông tin", icon: Info },
  ]

  const renderTabContent = () => {
    switch (activeTab) {
      case "display":
        return (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Độ phân giải màn hình</CardTitle>
              </CardHeader>
              <CardContent>
                <select className="w-full p-2 border border-gray-300 rounded">
                  <option>1920 x 1080 (Khuyến nghị)</option>
                  <option>1366 x 768</option>
                  <option>1280 x 720</option>
                </select>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Độ sáng</CardTitle>
              </CardHeader>
              <CardContent>
                <input type="range" min="0" max="100" defaultValue="75" className="w-full" />
              </CardContent>
            </Card>
          </div>
        )

      case "sound":
        return (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Âm lượng chính</CardTitle>
              </CardHeader>
              <CardContent>
                <input type="range" min="0" max="100" defaultValue="50" className="w-full" />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Thiết bị âm thanh</CardTitle>
              </CardHeader>
              <CardContent>
                <select className="w-full p-2 border border-gray-300 rounded">
                  <option>Loa (Realtek Audio)</option>
                  <option>Tai nghe</option>
                  <option>Bluetooth Audio</option>
                </select>
              </CardContent>
            </Card>
          </div>
        )

      case "security":
        return (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Bảo mật hệ thống</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {!hasPassword ? (
                  <div>
                    <h3 className="text-lg font-medium mb-3">Đặt mật khẩu bảo vệ</h3>
                    <p className="text-sm text-gray-600 mb-4">
                      Đặt mật khẩu để bảo vệ quyền truy cập vào cài đặt hệ thống
                    </p>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium mb-1">Mật khẩu mới</label>
                        <Input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Nhập mật khẩu..."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Xác nhận mật khẩu</label>
                        <Input
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Nhập lại mật khẩu..."
                        />
                      </div>
                      <Button
                        onClick={() => {
                          if (newPassword && newPassword === confirmPassword) {
                            localStorage.setItem("hlounh_password", newPassword)
                            setHasPassword(true)
                            setNewPassword("")
                            setConfirmPassword("")
                            alert("Đã đặt mật khẩu thành công!")
                          } else {
                            alert("Mật khẩu không khớp!")
                          }
                        }}
                        disabled={!newPassword || newPassword !== confirmPassword}
                      >
                        Đặt mật khẩu
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div>
                    <h3 className="text-lg font-medium mb-3">Thay đổi mật khẩu</h3>
                    <div className="space-y-3">
                      <div>
                        <label className="block text-sm font-medium mb-1">Mật khẩu hiện tại</label>
                        <Input
                          type="password"
                          value={currentPassword}
                          onChange={(e) => setCurrentPassword(e.target.value)}
                          placeholder="Nhập mật khẩu hiện tại..."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Mật khẩu mới</label>
                        <Input
                          type="password"
                          value={newPassword}
                          onChange={(e) => setNewPassword(e.target.value)}
                          placeholder="Nhập mật khẩu mới..."
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">Xác nhận mật khẩu mới</label>
                        <Input
                          type="password"
                          value={confirmPassword}
                          onChange={(e) => setConfirmPassword(e.target.value)}
                          placeholder="Nhập lại mật khẩu mới..."
                        />
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => {
                            const savedPassword = localStorage.getItem("hlounh_password")
                            if (currentPassword === savedPassword && newPassword && newPassword === confirmPassword) {
                              localStorage.setItem("hlounh_password", newPassword)
                              setCurrentPassword("")
                              setNewPassword("")
                              setConfirmPassword("")
                              alert("Đã thay đổi mật khẩu thành công!")
                            } else {
                              alert("Mật khẩu hiện tại không đúng hoặc mật khẩu mới không khớp!")
                            }
                          }}
                          disabled={!currentPassword || !newPassword || newPassword !== confirmPassword}
                        >
                          Thay đổi
                        </Button>
                        <Button
                          variant="destructive"
                          onClick={() => {
                            const savedPassword = localStorage.getItem("hlounh_password")
                            if (currentPassword === savedPassword) {
                              localStorage.removeItem("hlounh_password")
                              setHasPassword(false)
                              setCurrentPassword("")
                              alert("Đã xóa mật khẩu thành công!")
                            } else {
                              alert("Mật khẩu hiện tại không đúng!")
                            }
                          }}
                        >
                          Xóa mật khẩu
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )

      case "about":
        return (
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>HLounh OS</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <p>
                  <strong>Phiên bản:</strong> 1.0.0
                </p>
                <p>
                  <strong>Kiến trúc:</strong> x64
                </p>
                <p>
                  <strong>Bộ nhớ RAM:</strong> 8 GB
                </p>
                <p>
                  <strong>Bộ xử lý:</strong> Intel Core i5
                </p>
                <p>
                  <strong>Ngày phát hành:</strong> 2024
                </p>
              </CardContent>
            </Card>
          </div>
        )

      default:
        return <div className="text-center py-8 text-gray-500">Tính năng đang được phát triển...</div>
    }
  }

  return (
    <div className="h-full flex bg-white">
      {/* Sidebar */}
      <div className="w-64 bg-gray-50 border-r border-gray-200 p-4">
        <h2 className="text-lg font-semibold mb-4">Cài đặt</h2>
        <div className="space-y-1">
          {settingsTabs.map((tab) => {
            const IconComponent = tab.icon
            return (
              <Button
                key={tab.id}
                variant={activeTab === tab.id ? "default" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab(tab.id)}
              >
                <IconComponent className="w-4 h-4 mr-2" />
                {tab.name}
              </Button>
            )
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 overflow-auto">
        <h1 className="text-2xl font-bold mb-6">{settingsTabs.find((tab) => tab.id === activeTab)?.name}</h1>
        {renderTabContent()}
      </div>
    </div>
  )
}

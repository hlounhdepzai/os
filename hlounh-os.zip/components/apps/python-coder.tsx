"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Play, Save, Folder, RotateCcw } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface CodeExample {
  title: string
  description: string
  code: string
  category: string
}

const codeExamples: CodeExample[] = [
  {
    title: "Hello World",
    description: "Chương trình Python đầu tiên",
    code: `# Chương trình Hello World đầu tiên
print("Xin chào, HLounh OS!")
print("Chào mừng đến với Python Coder!")`,
    category: "Cơ bản",
  },
  {
    title: "Biến và kiểu dữ liệu",
    description: "Làm việc với các kiểu dữ liệu cơ bản",
    code: `# Các kiểu dữ liệu cơ bản trong Python
name = "HLounh OS"
version = 1.0
is_active = True
users = ["admin", "user", "guest"]

print(f"Tên: {name}")
print(f"Phiên bản: {version}")
print(f"Đang hoạt động: {is_active}")
print(f"Người dùng: {users}")

# Kiểm tra kiểu dữ liệu
print(f"Kiểu của name: {type(name)}")
print(f"Kiểu của version: {type(version)}")`,
    category: "Cơ bản",
  },
  {
    title: "Vòng lặp và điều kiện",
    description: "Cấu trúc điều khiển trong Python",
    code: `# Vòng lặp for
print("Đếm từ 1 đến 5:")
for i in range(1, 6):
    print(f"Số {i}")

# Điều kiện if-else
age = 18
if age >= 18:
    print("Bạn đã đủ tuổi trưởng thành")
else:
    print("Bạn chưa đủ tuổi trưởng thành")

# Vòng lặp while
count = 0
print("\\nĐếm ngược:")
while count < 3:
    print(f"Còn {3-count} giây...")
    count += 1
print("Hoàn thành!")`,
    category: "Cơ bản",
  },
  {
    title: "Hàm (Functions)",
    description: "Tạo và sử dụng hàm trong Python",
    code: `# Định nghĩa hàm
def chao_mung(ten, tuoi=18):
    """Hàm chào mừng người dùng"""
    return f"Xin chào {ten}, bạn {tuoi} tuổi!"

def tinh_tong(a, b):
    """Hàm tính tổng hai số"""
    return a + b

def tinh_giai_thua(n):
    """Hàm tính giai thừa"""
    if n <= 1:
        return 1
    return n * tinh_giai_thua(n - 1)

# Sử dụng hàm
print(chao_mung("HLounh"))
print(chao_mung("Python", 30))
print(f"5 + 3 = {tinh_tong(5, 3)}")
print(f"5! = {tinh_giai_thua(5)}")`,
    category: "Trung bình",
  },
  {
    title: "Làm việc với danh sách",
    description: "Các thao tác với list trong Python",
    code: `# Tạo và thao tác với danh sách
fruits = ["táo", "chuối", "cam", "nho"]
print(f"Danh sách trái cây: {fruits}")

# Thêm phần tử
fruits.append("dưa hấu")
fruits.insert(1, "xoài")
print(f"Sau khi thêm: {fruits}")

# Xóa phần tử
fruits.remove("cam")
print(f"Sau khi xóa cam: {fruits}")

# List comprehension
numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print(f"Bình phương: {squares}")

# Lọc danh sách
even_numbers = [x for x in range(10) if x % 2 == 0]
print(f"Số chẵn: {even_numbers}")`,
    category: "Trung bình",
  },
  {
    title: "Class và Object",
    description: "Lập trình hướng đối tượng",
    code: `# Định nghĩa class
class NguoiDung:
    def __init__(self, ten, tuoi, email):
        self.ten = ten
        self.tuoi = tuoi
        self.email = email
        self.dang_hoat_dong = True
    
    def chao(self):
        return f"Xin chào, tôi là {self.ten}"
    
    def sinh_nhat(self):
        self.tuoi += 1
        print(f"Chúc mừng sinh nhật! Bây giờ bạn {self.tuoi} tuổi")
    
    def __str__(self):
        return f"NguoiDung(ten='{self.ten}', tuoi={self.tuoi})"

# Tạo đối tượng
user1 = NguoiDung("Alice", 25, "alice@example.com")
user2 = NguoiDung("Bob", 30, "bob@example.com")

print(user1.chao())
print(user2.chao())
user1.sinh_nhat()
print(user1)`,
    category: "Nâng cao",
  },
  {
    title: "Xử lý file",
    description: "Đọc và ghi file trong Python",
    code: `# Ghi file
content = """Đây là nội dung file test.
HLounh OS Python Coder
Dòng thứ 3"""

# Mô phỏng ghi file
print("Nội dung sẽ được ghi vào file:")
print(content)
print("\\n" + "="*30)

# Mô phỏng đọc file
lines = content.split("\\n")
print("Đọc file theo từng dòng:")
for i, line in enumerate(lines, 1):
    print(f"Dòng {i}: {line}")

# Xử lý JSON
import json

data = {
    "name": "HLounh OS",
    "version": "1.0.0",
    "features": ["File Manager", "Python Coder", "Web Browser"]
}

json_string = json.dumps(data, ensure_ascii=False, indent=2)
print("\\nDữ liệu JSON:")
print(json_string)`,
    category: "Nâng cao",
  },
  {
    title: "Xử lý ngoại lệ",
    description: "Try-catch và xử lý lỗi",
    code: `# Xử lý ngoại lệ cơ bản
def chia_so(a, b):
    try:
        ket_qua = a / b
        return f"{a} ÷ {b} = {ket_qua}"
    except ZeroDivisionError:
        return "Lỗi: Không thể chia cho 0!"
    except TypeError:
        return "Lỗi: Kiểu dữ liệu không hợp lệ!"
    except Exception as e:
        return f"Lỗi không xác định: {e}"

# Test các trường hợp
print(chia_so(10, 2))
print(chia_so(10, 0))
print(chia_so("10", 2))

# Try-except-finally
def xu_ly_file():
    try:
        print("Mở file...")
        # Mô phỏng xử lý file
        data = [1, 2, 3, 4, 5]
        print(f"Dữ liệu: {data}")
        return sum(data)
    except Exception as e:
        print(f"Lỗi: {e}")
        return None
    finally:
        print("Đóng file (luôn được thực hiện)")

result = xu_ly_file()
print(f"Kết quả: {result}")`,
    category: "Nâng cao",
  },
]

export default function PythonCoder() {
  const [code, setCode] = useState(`# Chào mừng đến với Python Coder!
# Viết code Python của bạn tại đây

print("Xin chào từ HLounh OS!")
print("Sẵn sàng để code Python!")`)
  const [output, setOutput] = useState("")
  const [isRunning, setIsRunning] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("Tất cả")
  const [showExamples, setShowExamples] = useState(true)
  const textareaRef = useRef<HTMLTextAreaElement>(null)

  const categories = ["Tất cả", "Cơ bản", "Trung bình", "Nâng cao"]

  const filteredExamples =
    selectedCategory === "Tất cả"
      ? codeExamples
      : codeExamples.filter((example) => example.category === selectedCategory)

  const runCode = async () => {
    setIsRunning(true)
    setOutput("Đang chạy code...\n")

    try {
      // Mô phỏng chạy Python code
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Đây là mô phỏng - trong thực tế cần Python interpreter
      const simulatedOutput = simulatePythonExecution(code)
      setOutput(simulatedOutput)
    } catch (error) {
      setOutput(`Lỗi: ${error}`)
    } finally {
      setIsRunning(false)
    }
  }

  const simulatePythonExecution = (code: string): string => {
    let output = ""
    const lines = code.split("\n")

    try {
      for (const line of lines) {
        const trimmedLine = line.trim()

        // Bỏ qua comment và dòng trống
        if (trimmedLine.startsWith("#") || trimmedLine === "") continue

        // Xử lý print statements
        const printMatch = trimmedLine.match(/print\s*$$\s*(.+)\s*$$/)
        if (printMatch) {
          let content = printMatch[1]

          // Xử lý f-string cơ bản
          if (content.startsWith('f"') || content.startsWith("f'")) {
            content = content.substring(2, content.length - 1)
            // Mô phỏng xử lý f-string đơn giản
            content = content.replace(/\{([^}]+)\}/g, (match, expr) => {
              // Đây là mô phỏng đơn giản
              if (expr.includes("+")) {
                const parts = expr.split("+").map((p) => p.trim())
                if (parts.every((p) => !isNaN(Number(p)))) {
                  return String(parts.reduce((sum, p) => sum + Number(p), 0))
                }
              }
              return expr // Trả về biểu thức gốc nếu không xử lý được
            })
          } else if (content.startsWith('"') || content.startsWith("'")) {
            content = content.substring(1, content.length - 1)
          }

          // Xử lý escape characters
          content = content.replace(/\\n/g, "\n").replace(/\\t/g, "\t")

          output += content + "\n"
        }

        // Xử lý các phép tính đơn giản
        else if (trimmedLine.includes("=") && !trimmedLine.includes("==")) {
          // Mô phỏng gán biến
          continue
        }

        // Xử lý các cấu trúc khác (mô phỏng đơn giản)
        else if (
          trimmedLine.startsWith("for ") ||
          trimmedLine.startsWith("while ") ||
          trimmedLine.startsWith("if ") ||
          trimmedLine.startsWith("def ")
        ) {
          // Mô phỏng cấu trúc điều khiển
          continue
        }
      }

      if (output === "") {
        output = "Code đã chạy thành công (không có output)\n"
      }
    } catch (error) {
      output = `Lỗi trong quá trình thực thi: ${error}\n`
    }

    return output
  }

  const clearOutput = () => {
    setOutput("")
  }

  const loadExample = (example: CodeExample) => {
    setCode(example.code)
    setShowExamples(false)
  }

  const saveCode = () => {
    const blob = new Blob([code], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "python_code.py"
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="h-full flex bg-gray-100">
      {/* Sidebar - Examples */}
      {showExamples && (
        <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
          <div className="p-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold mb-3">Ví dụ Python</h2>
            <div className="flex flex-wrap gap-1">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          <div className="flex-1 overflow-auto p-4 space-y-3">
            {filteredExamples.map((example, index) => (
              <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{example.title}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-xs text-gray-600 mb-2">{example.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">{example.category}</span>
                    <Button size="sm" onClick={() => loadExample(example)}>
                      Tải
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Main Editor Area */}
      <div className="flex-1 flex flex-col">
        {/* Toolbar */}
        <div className="flex items-center justify-between p-3 bg-white border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <Button onClick={runCode} disabled={isRunning} className="bg-green-600 hover:bg-green-700">
              <Play className="w-4 h-4 mr-1" />
              {isRunning ? "Đang chạy..." : "Chạy"}
            </Button>
            <Button variant="outline" onClick={clearOutput}>
              <RotateCcw className="w-4 h-4 mr-1" />
              Xóa output
            </Button>
            <Button variant="outline" onClick={saveCode}>
              <Save className="w-4 h-4 mr-1" />
              Lưu
            </Button>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" onClick={() => setShowExamples(!showExamples)}>
              <Folder className="w-4 h-4 mr-1" />
              {showExamples ? "Ẩn" : "Hiện"} ví dụ
            </Button>
          </div>
        </div>

        {/* Code Editor and Output */}
        <div className="flex-1 flex">
          {/* Code Editor */}
          <div className="flex-1 flex flex-col">
            <div className="p-2 bg-gray-50 border-b border-gray-200">
              <span className="text-sm font-medium">Code Editor</span>
            </div>
            <textarea
              ref={textareaRef}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 p-4 font-mono text-sm resize-none border-none outline-none"
              placeholder="Viết code Python của bạn tại đây..."
              spellCheck={false}
            />
          </div>

          {/* Output Panel */}
          <div className="w-1/2 flex flex-col border-l border-gray-200">
            <div className="p-2 bg-gray-50 border-b border-gray-200">
              <span className="text-sm font-medium">Output</span>
            </div>
            <div className="flex-1 p-4 bg-black text-green-400 font-mono text-sm overflow-auto">
              <pre className="whitespace-pre-wrap">{output || "Chưa có output. Nhấn 'Chạy' để thực thi code."}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
